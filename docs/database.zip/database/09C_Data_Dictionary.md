# MetaForge Recruiter Application V3 — Master Data Dictionary

**Document ID:** `docs/database/09C_Data_Dictionary.md`  
**Application:** MetaForge Recruiter Application (Version 3)  
**Target Stack:** NestJS + Mongoose (v8+) + MongoDB (v7+)  

---

## 1. Collection Schemas Specification

---

### 1.1 Collection: `users`
**Purpose:** System user accounts, credentials, role assignments, and capability flags.

| Field Name | Type | Required | Default | Enum / Reference | Validation | Index | Description |
|---|---|---|---|---|---|---|---|
| `_id` | ObjectId | Yes | Auto | — | Auto | PK | Unique document ID |
| `userId` | String | Yes | `USR-xxxx` | — | Unique, Regex `^USR-\d{5}$` | Unique | Public User Identifier |
| `name` | String | Yes | — | — | Min length 2 | Text | Full User Name |
| `email` | String | Yes | — | — | Valid Email Format | Unique | Work Email Address (Login) |
| `passwordHash` | String | Yes | — | — | Bcrypt / Argon2 Hash | No | Encrypted Password |
| `role` | String | Yes | `recruiter` | Enum: `superadmin`, `admin`, `lead`, `recruiter`, `devteam`, `client` | In Enum Array | Index | System Access Role |
| `teamId` | ObjectId | No | null | Ref: `teams._id` | Valid ObjectId | Index | Team membership link |
| `clientId` | ObjectId | No | null | Ref: `clients._id` | Required if role == 'client' | Index | Client account link |
| `avatarUrl` | String | No | null | — | URL Format | No | Profile photo path |
| `phone` | String | No | null | — | Phone Regex | No | Contact Phone |
| `active` | Boolean | Yes | `true` | — | Boolean | Index | Account active toggle |
| `capabilities` | Object | Yes | `{}` | Embedded | Object Schema | No | Capability overrides |
| `capabilities.addCandidates` | Boolean | Yes | `true` | — | Boolean | No | Can upload candidates |
| `capabilities.submitToClients`| Boolean | Yes | `false` | — | Boolean | No | Can forward to clients |
| `capabilities.scheduleInterviews`| Boolean | Yes | `true` | — | Boolean | No | Can schedule rounds |
| `capabilities.exportReportsCsv`| Boolean | Yes | `false` | — | Boolean | No | Can export CSV reports |
| `capabilities.reassignRequirements`| Boolean | Yes | `false` | — | Boolean | No | Can reassign job demand |
| `lastLoginAt` | Date | No | null | — | Date | No | Timestamp of last signin |
| `createdAt` | Date | Yes | `now()` | — | Date | Index | Document Creation Date |
| `updatedAt` | Date | Yes | `now()` | — | Date | No | Document Modification Date |

---

### 1.2 Collection: `clients`
**Purpose:** B2B Client Accounts, SLA definitions, corporate POC contacts, and delivery analytics.

| Field Name | Type | Required | Default | Enum / Reference | Validation | Index | Description |
|---|---|---|---|---|---|---|---|
| `_id` | ObjectId | Yes | Auto | — | Auto | PK | Unique document ID |
| `clientId` | String | Yes | `CLI-xxxx` | — | Unique, Regex `^CLI-\d{4}$` | Unique | Public Client Code |
| `clientName` | String | Yes | — | — | Min length 2 | Unique/Text | Corporate Account Name |
| `domain` | String | Yes | `Information Technology` | Enum: `IT`, `BFSI`, `Healthcare`, `E-Commerce`, `Manufacturing` | In Enum | Index | Industry Verticals |
| `tier` | String | Yes | `Tier-1` | Enum: `Tier-1`, `Tier-2`, `Enterprise`, `Global` | In Enum | Index | Client Business Tier |
| `status` | String | Yes | `Active` | Enum: `Active`, `On Hold`, `Inactive`, `Archived` | In Enum | Index | Commercial Status |
| `slaDays` | Number | Yes | 5 | — | Min 1, Max 90 | No | Contractual SLA Days |
| `pocContacts` | Array | Yes | `[]` | Embedded Object Array | Min 1 element | No | Key Client Contacts |
| `pocContacts.name` | String | Yes | — | — | Non-empty | No | Contact Name |
| `pocContacts.email` | String | Yes | — | — | Email Regex | No | Contact Email |
| `pocContacts.phone` | String | Yes | — | — | Phone Regex | No | Contact Phone |
| `pocContacts.designation`| String | No | — | — | — | No | Contact Role |
| `accountLeadId` | ObjectId | No | null | Ref: `users._id` | Valid ObjectId | Index | Assigned Internal Lead |
| `deliveryGapScore` | Number | No | 0.0 | — | Min 0, Max 100 | No | Delivery Performance Rating |
| `agreementsUrl` | String | No | null | Ref: `file_metadata._id` | URL/ObjectId | No | Client MSA/SOW Document |
| `createdAt` | Date | Yes | `now()` | — | Date | Index | Creation Timestamp |

---

### 1.3 Collection: `requirements`
**Purpose:** Job Demands, staffing requirements, priority, assigned recruiters, openings, and SLA tracking.

| Field Name | Type | Required | Default | Enum / Reference | Validation | Index | Description |
|---|---|---|---|---|---|---|---|
| `_id` | ObjectId | Yes | Auto | — | Auto | PK | Unique document ID |
| `reqCode` | String | Yes | — | — | Unique `REQ-YYYY-MM-DD-XXX` | Unique | Public Requirement ID |
| `title` | String | Yes | — | — | Min length 3 | Text | Job Position Title |
| `clientId` | ObjectId | Yes | — | Ref: `clients._id` | Valid ObjectId | Index | Associated Client |
| `clientName` | String | Yes | — | — | Denormalized for UI | Index | Fast UI rendering |
| `priority` | String | Yes | `Medium` | Enum: `High`, `Medium`, `Low`, `Urgent` | In Enum | Index | Priority Tier |
| `status` | String | Yes | `Open` | Enum: `Open`, `Assigned`, `In Progress`, `On Hold`, `Reopen`, `Closed` | In Enum | Index | Workflow Status |
| `assignmentStatus`| String | Yes | `Unassigned`| Enum: `Unassigned`, `Assigned`, `In Progress`, `Closed` | In Enum | Index | Team Assignment Status |
| `openings` | Number | Yes | 1 | — | Min 1 | No | Required Positions Count |
| `placedCount` | Number | Yes | 0 | — | Min 0 | No | Candidates Joined Count |
| `budgetRange` | Object | No | — | Embedded | — | No | Annual Salary Budget |
| `budgetRange.min` | Number | No | 0 | — | Min 0 | No | Budget Min (LPA / USD) |
| `budgetRange.max` | Number | No | 0 | — | Min 0 | No | Budget Max (LPA / USD) |
| `budgetRange.currency`| String | Yes | `INR` | Enum: `INR`, `USD`, `EUR` | In Enum | No | Currency |
| `assignedLeadId` | ObjectId | No | null | Ref: `users._id` | Lead Role Check | Index | Assigned Team Lead |
| `assignedRecruiterIds`| Array | Yes | `[]` | Ref: `users._id` Array | User Role Check | Index | Recruiter Working List |
| `skillsRequired` | Array | Yes | `[]` | String Array | — | Text/Index | Key Tech Stack |
| `experienceRange` | Object | No | — | Embedded | — | No | Required YOE Range |
| `experienceRange.min`| Number | No | 0 | — | Min 0 | No | Min Experience Years |
| `experienceRange.max`| Number | No | 0 | — | Min 0 | No | Max Experience Years |
| `location` | String | No | `Hybrid` | — | — | Index | Work Location |
| `emailArrivedTime` | Date | Yes | `now()` | — | Date | Index | Demand Received Time |
| `revokeRequested` | Boolean | Yes | `false` | — | Boolean | Index | Revoke Flag |
| `revokeReason` | String | No | null | — | Max length 500 | No | Revoke Explanation |
| `createdAt` | Date | Yes | `now()` | — | Date | Index | Ingestion Timestamp |

---

### 1.4 Collection: `candidates`
**Purpose:** Talent Repository, candidate profile metrics, CTC breakdown, notice period, and skill tag bank.

| Field Name | Type | Required | Default | Enum / Reference | Validation | Index | Description |
|---|---|---|---|---|---|---|---|
| `_id` | ObjectId | Yes | Auto | — | Auto | PK | Unique document ID |
| `candidateId` | String | Yes | — | — | Unique `CAND-XXXXX` | Unique | Public Candidate ID |
| `name` | String | Yes | — | — | Min length 2 | Text | Candidate Full Name |
| `email` | String | Yes | — | — | Email Format | Unique | Primary Email |
| `phone` | String | Yes | — | — | Phone Regex | Unique | Primary Phone Number |
| `linkedInUrl` | String | No | null | — | URL Format | No | LinkedIn Profile Link |
| `currentCompany` | String | No | null | — | — | Text | Current Employer |
| `qualification` | String | No | null | — | — | No | Highest Qualification |
| `totalExperienceYears`| Number | Yes | 0.0 | — | Min 0, Max 50 | Index | Total YOE |
| `relevantExperienceYears`| Number| Yes | 0.0 | — | Min 0, Max 50 | No | Relevant Skill YOE |
| `currentCtc` | Number | No | 0.0 | — | Min 0 | No | Current CTC (LPA) |
| `expectedCtc` | Number | No | 0.0 | — | Min 0 | No | Expected CTC (LPA) |
| `noticePeriodDays` | Number | Yes | 30 | — | Min 0, Max 180 | Index | Notice Period (Days) |
| `currentLocation` | String | No | null | — | — | Index | Present City |
| `preferredLocation`| String | No | null | — | — | No | Preferred Work City |
| `offerInHand` | String | Yes | `No` | Enum: `No`, `Yes`, `In Pipeline`, `Multiple` | In Enum | Index | Existing Offer Flag |
| `skills` | Array | Yes | `[]` | String Array | — | Text/Index | Primary Tech Stack Tags |
| `resumeFileId` | ObjectId | No | null | Ref: `file_metadata._id` | ObjectId | Index | Master Resume Reference |
| `sourcedByRecruiterId`| ObjectId| Yes| — | Ref: `users._id` | Valid ObjectId | Index | Sourcing Recruiter |
| `status` | String | Yes | `New` | Enum: `New`, `Parsed`, `Submitted`, `Interviewing`, `Offered`, `Placed` | In Enum | Index | Candidate Status |
| `createdAt` | Date | Yes | `now()` | — | Date | Index | Database Creation Date |

---

### 1.5 Collection: `submissions`
**Purpose:** Core recruitment transaction linking candidate to requirement across multi-tier approval stages.

| Field Name | Type | Required | Default | Enum / Reference | Validation | Index | Description |
|---|---|---|---|---|---|---|---|
| `_id` | ObjectId | Yes | Auto | — | Auto | PK | Unique document ID |
| `submissionId` | String | Yes | — | — | Unique `SUB-XXXXX` | Unique | Public Submission ID |
| `candidateId` | ObjectId | Yes | — | Ref: `candidates._id` | Valid ObjectId | Compound Unique (with req) | Submitted Candidate |
| `requirementId` | ObjectId | Yes | — | Ref: `requirements._id` | Valid ObjectId | Compound Unique (with cand) | Target Requirement |
| `clientId` | ObjectId | Yes | — | Ref: `clients._id` | Valid ObjectId | Index | Client Account Link |
| `recruiterId` | ObjectId | Yes | — | Ref: `users._id` | Recruiter Role | Index | Sourcing Recruiter |
| `leadId` | ObjectId | No | null | Ref: `users._id` | Lead Role | Index | Reviewing Team Lead |
| `stage` | String | Yes | `Submitted` | Enum: `Submitted`, `Submitted to Lead`, `Submitted to Client`, `Client Review`, `Interview Scheduled`, `Offered`, `Placed`, `Rejected` | In Enum | Index | Funnel Stage |
| `leadApprovalStatus`| String | Yes | `Pending` | Enum: `Pending`, `Approved`, `Rejected`, `Forwarded` | In Enum | Index | Lead Gate Status |
| `matchScore` | Number | Yes | 0.0 | — | Range 0.0 to 100.0 | Index | AI Match Percentage |
| `submittedAt` | Date | Yes | `now()` | — | Date | Index | Recruiter Submission Date |
| `leadApprovedAt` | Date | No | null | — | Date | No | Lead Approval Date |
| `clientForwardedAt`| Date | No | null | — | Date | No | Client Forwarding Date |
| `rejectionReason` | String | No | null | — | Max length 500 | No | Reason if rejected |
| `updatedAt` | Date | Yes | `now()` | — | Date | No | Last Updated Timestamp |

---

### 1.6 Collection: `interviews`
**Purpose:** Interview Scheduling, Google Meet/Teams video links, stage tracking, and evaluator assignments.

| Field Name | Type | Required | Default | Enum / Reference | Validation | Index | Description |
|---|---|---|---|---|---|---|---|
| `_id` | ObjectId | Yes | Auto | — | Auto | PK | Unique document ID |
| `interviewId` | String | Yes | — | — | Unique `INT-XXXXX` | Unique | Public Interview Code |
| `submissionId` | ObjectId | Yes | — | Ref: `submissions._id` | Valid ObjectId | Index | Linked Submission |
| `candidateId` | ObjectId | Yes | — | Ref: `candidates._id` | Valid ObjectId | Index | Interviewee Candidate |
| `requirementId` | ObjectId | Yes | — | Ref: `requirements._id` | Valid ObjectId | Index | Job Requirement |
| `round` | String | Yes | `Screening` | Enum: `Screening`, `L1 Technical`, `L2 Technical`, `Manager Round`, `Client Round`, `HR Round` | In Enum | Index | Interview Stage |
| `dateTime` | Date | Yes | — | — | Future Date | Index | Scheduled Time |
| `mode` | String | Yes | `Online` | Enum: `Online`, `In-Person`, `Telephonic` | In Enum | No | Interview Channel |
| `meetingUrl` | String | No | null | — | URL Format | No | Google Meet / Teams Link |
| `interviewerName` | String | Yes | — | — | Min length 2 | No | Evaluator Name |
| `interviewerEmail`| String | Yes | — | — | Email Regex | Index | Evaluator Email |
| `status` | String | Yes | `Scheduled` | Enum: `Scheduled`, `Confirmed`, `In Progress`, `Completed`, `Passed`, `Rejected`, `Rescheduled`, `Cancelled` | In Enum | Index | Interview Status |
| `reminderSent` | Boolean | Yes | `false` | — | Boolean | No | Automated Reminder Flag |
| `createdAt` | Date | Yes | `now()` | — | Date | Index | Scheduling Timestamp |

---

### 1.7 Collection: `offers` & Onboarding Track
**Purpose:** Release of offer letters, CTC offered, joining dates, backed-out tracking, and non-joining reasons.

| Field Name | Type | Required | Default | Enum / Reference | Validation | Index | Description |
|---|---|---|---|---|---|---|---|
| `_id` | ObjectId | Yes | Auto | — | Auto | PK | Unique document ID |
| `offerId` | String | Yes | — | — | Unique `OFR-XXXXX` | Unique | Public Offer ID |
| `submissionId` | ObjectId | Yes | — | Ref: `submissions._id` | Unique ObjectId | Unique | Linked Submission |
| `candidateId` | ObjectId | Yes | — | Ref: `candidates._id` | Valid ObjectId | Index | Candidate Link |
| `requirementId` | ObjectId | Yes | — | Ref: `requirements._id` | Valid ObjectId | Index | Requirement Link |
| `offeredCtc` | Number | Yes | — | — | Min 0 | No | Annual Offered Compensation |
| `offerReleaseDate`| Date | Yes | `now()` | — | Date | Index | Date Offer Release |
| `joiningDate` | Date | Yes | — | — | Date | Index | Expected Joining Date |
| `status` | String | Yes | `Offer Released` | Enum: `Offer Released`, `Accepted`, `Joined`, `Declined`, `Backed Out` | In Enum | Index | Onboarding Outcome |
| `declinedReason` | String | No | null | — | Max length 500 | No | Non-joining reason |
| `notJoinedNote` | String | No | null | — | Max length 1000 | No | Recruiter notes |
| `updatedAt` | Date | Yes | `now()` | — | Date | No | Status update date |
